﻿namespace CodeTheFuture.DataAccess {
    
    
    public partial class DataSet {
    }
}

namespace CodeTheFuture.DataAccess.DataSetTableAdapters {
    
    
    public partial class RecipesXTableAdapter {
    }
}
