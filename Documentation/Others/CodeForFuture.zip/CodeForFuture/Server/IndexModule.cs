﻿namespace Server
{
    using Nancy;
    using Newtonsoft.Json;
    using CodeTheFuture.CoreLib;

    public class IndexModule : NancyModule
    {
        public IndexModule()
        {
            var user = User.Get("sk180579@gmail.com");

            Get["/"] = parameters =>
            {
                return View["Index"];
            };

            Get["/recipes"] = _ =>
            {
                return JsonConvert.SerializeObject(user.Suggestions);
            };

            //Put["/container"] = parameters => // id currentlevel
            //{
            //    var requestBody = this.Request.Body;
            //    int requestBodyLength = (int)requestBody.Length; //this is a dynamic variable.
            //    byte[] ingredientIDs = new byte[requestBodyLength];
            //    requestBody.Read(ingredientIDs, 0, requestBodyLength);

            //    foreach (var ingredientID in ingredientIDs)
            //    {
            //        //Ingredient.Update(ingredientID, true);
            //    }

            //    return 200;
            //};

            Get["/containers"] = _ =>
            {
                return JsonConvert.SerializeObject(Container.GetAll(user.ID));
            };

            Get["/containers/{value:int}"] = parameters =>
            {
                return JsonConvert.SerializeObject(Container.Get(parameters.value));
            };
            
            Get["/recipes/{value:int}"] = parameters =>
            {
                var recipe = Recipe.Get(parameters.value);

                return JsonConvert.SerializeObject(new { LineItems = recipe.LineItems, Directions = recipe.Directions});
            };
        }
    }
}