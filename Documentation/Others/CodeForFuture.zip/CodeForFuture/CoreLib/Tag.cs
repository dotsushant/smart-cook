﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Tag
    {
        internal static DataAccess.DataSetTableAdapters.TagsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.TagsTableAdapter();

        public static Tag Get(long id)
        {
            Tag Tag = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    Tag = new Tag(data.FirstOrDefault());
                }
            }

            return Tag;
        }

        public static IEnumerable<Tag> GetAll()
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAll())
                {
                    yield return new Tag(row);
                }
            }
        }

        public static Tag Add(string name)
        {
            Tag Tag = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(name) > 0)
                {
                    Tag = GetAll().LastOrDefault();
                }
            }

            return Tag;
        }

        public Tag() { }

        public Tag(DataAccess.DataSet.TagsRow row)
        {
            ID = row.ID;
            Name = row.Name;
        }

        public long ID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }
    }
}