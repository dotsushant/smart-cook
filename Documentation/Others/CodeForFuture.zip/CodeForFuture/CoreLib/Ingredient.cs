﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Ingredient
    {
        internal static DataAccess.DataSetTableAdapters.IngredientsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.IngredientsTableAdapter();

        public static Ingredient Get(long id)
        {
            Ingredient Ingredient = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    Ingredient = new Ingredient(data.FirstOrDefault());
                }
            }

            return Ingredient;
        }

        public static Ingredient Get(string name)
        {
            Ingredient Ingredient = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByName(name);

                if (data.Count > 0)
                {
                    Ingredient = new Ingredient(data.FirstOrDefault());
                }
            }

            return Ingredient;
        }

        public static IEnumerable<Ingredient> GetAll()
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAll())
                {
                    yield return new Ingredient(row);
                }
            }
        }

        public static Ingredient Add(string name, string description, string imageUrl, string guid)
        {
            Ingredient Ingredient = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(name, description, imageUrl, guid) > 0)
                {
                    Ingredient = GetAll().LastOrDefault();
                }
            }

            return Ingredient;
        }


        public Ingredient() { }

        public Ingredient(DataAccess.DataSet.IngredientsRow row)
        {
            ID = row.ID;
            Name = row.Name;
            Description = row.Description;
            ImageUrl = row.ImageUrl;
            Guid = row.Guid;
        }

        public long ID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public string ImageUrl
        {
            get;
            set;
        }

        public string Guid
        {
            get;
            set;
        }
    }
}