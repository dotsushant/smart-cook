﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Unit
    {
        internal static DataAccess.DataSetTableAdapters.UnitsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.UnitsTableAdapter();

        public static Unit Get(long id)
        {
            Unit Unit = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    Unit = new Unit(data.FirstOrDefault());
                }
            }

            return Unit;
        }

        public static IEnumerable<Unit> GetAll()
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAll())
                {
                    yield return new Unit(row);
                }
            }
        }

        public static Unit Add(string name)
        {
            Unit unit = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(name) > 0)
                {
                    unit = GetAll().LastOrDefault();
                }
            }

            return unit;
        }

        public Unit() { }

        public Unit(DataAccess.DataSet.UnitsRow row)
        {
            ID = row.ID;
            Name = row.Name;
        }

        public long ID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }
    }
}