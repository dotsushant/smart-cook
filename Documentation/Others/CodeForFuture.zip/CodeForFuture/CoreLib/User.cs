﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class User
    {
        static DataAccess.DataSetTableAdapters.UsersTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.UsersTableAdapter();

        public static User Get(long id)
        {
            User user = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    user = new User(data.FirstOrDefault());
                }
            }

            return user;
        }

        public static User Get(string email)
        {
            User user = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByEmail(email);

                if (data.Count > 0)
                {
                    user = new User(data.FirstOrDefault());
                }
            }

            return user;
        }

        public static IEnumerable<User> GetAll()
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAll())
                {
                    yield return new User(row);
                } 
            }
        }

        public static User Add(string fName, string lName, string email)
        {
            User user = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(fName, lName, email) > 0)
                {
                    user = Get(email);
                }
            }

            return user;
        }

        public User() { }

        public User(DataAccess.DataSet.UsersRow row)
        {
            ID = row.ID;
            FirstName = row.FirstName;
            LastName = row.LastName;
            Email = row.Email;
        }

        public long ID
        {
            get;
            set;
        }

        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }

        public string Email
        {
            get;
            set;
        }

        public IEnumerable<Recipe> Recipes
        {
            get
            {
                return Recipe.GetAll(ID);
            }
        }

        public IEnumerable<Recipe> Suggestions
        {
            get
            {
                return Recipe.GetSuggestions(ID);
            }
        }

        public IEnumerable<Container> Containers
        {
            get
            {
                return Container.GetAll(ID);
            }
        }


    }
}