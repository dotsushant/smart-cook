﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class IngredientTag
    {
        internal static DataAccess.DataSetTableAdapters.IngredientTagsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.IngredientTagsTableAdapter();

        public static IngredientTag Get(long id)
        {
            IngredientTag IngredientTag = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    IngredientTag = new IngredientTag(data.FirstOrDefault());
                }
            }

            return IngredientTag;
        }

        public static IEnumerable<IngredientTag> GetAll(long ingredientID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByIngredientID(ingredientID))
                {
                    yield return new IngredientTag(row);
                }
            }
        }

        public static IngredientTag Add(long ingredientID, long tagID)
        {
            IngredientTag IngredientTag = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(ingredientID, tagID) > 0)
                {
                    IngredientTag = GetAll(ingredientID).LastOrDefault();
                }
            }

            return IngredientTag;
        }

        public IngredientTag() { }

        public IngredientTag(DataAccess.DataSet.IngredientTagsRow row)
        {
            ID = row.ID;
            TagID = row.TagID;
        }

        public long ID
        {
            get;
            set;
        }

        public long TagID
        {
            get;
            set;
        }
    }
}