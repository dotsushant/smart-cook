﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class RecipeTag
    {
        internal static DataAccess.DataSetTableAdapters.RecipeTagsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.RecipeTagsTableAdapter();

        public static RecipeTag Get(long id)
        {
            RecipeTag RecipeTag = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    RecipeTag = new RecipeTag(data.FirstOrDefault());
                }
            }

            return RecipeTag;
        }

        public static IEnumerable<RecipeTag> GetAll(long recipeID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByRecipeID(recipeID))
                {
                    yield return new RecipeTag(row);
                }
            }
        }

        public static RecipeTag Add(long recipeID, long tagID)
        {
            RecipeTag RecipeTag = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(recipeID, tagID) > 0)
                {
                    RecipeTag = GetAll(recipeID).LastOrDefault();
                }
            }

            return RecipeTag;
        }

        public RecipeTag() { }

        public RecipeTag(DataAccess.DataSet.RecipeTagsRow row)
        {
            ID = row.ID;
            TagID = row.TagID;
        }

        public long ID
        {
            get;
            set;
        }

        public long TagID
        {
            get;
            set;
        }
    }
}