﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Direction
    {
        internal static DataAccess.DataSetTableAdapters.DirectionsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.DirectionsTableAdapter();

        public static Direction Get(long id)
        {
            Direction Direction = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    Direction = new Direction(data.FirstOrDefault());
                }
            }

            return Direction;
        }

        public static IEnumerable<Direction> GetAll(long recipeID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByRecipeID(recipeID))
                {
                    yield return new Direction(row);
                }
            }
        }

        public static Direction Add(long recipeID, string description)
        {
            Direction Direction = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(recipeID, description) > 0)
                {
                    Direction = GetAll(recipeID).LastOrDefault();
                }
            }

            return Direction;
        }

        public Direction() { }

        public Direction(DataAccess.DataSet.DirectionsRow row)
        {
            ID = row.ID;
            RecipeID = row.RecipeID;
            Description = row.Description;
        }

        public long ID
        {
            get;
            set;
        }

        public long RecipeID
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }
    }
}