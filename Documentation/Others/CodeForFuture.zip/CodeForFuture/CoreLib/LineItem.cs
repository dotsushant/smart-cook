﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class LineItem
    {
        internal static DataAccess.DataSetTableAdapters.LineItemsTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.LineItemsTableAdapter();

        public static LineItem Get(long id)
        {
            LineItem LineItem = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    LineItem = new LineItem(data.FirstOrDefault());
                }
            }

            return LineItem;
        }

        public static IEnumerable<LineItem> GetAll(long recipeID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByRecipeID(recipeID))
                {
                    yield return new LineItem(row);
                }
            }
        }

        public static LineItem Add(long recipeID, long ingredientID, string amount, string remarks)
        {
            LineItem lineItem = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(recipeID, ingredientID, amount, remarks) > 0)
                {
                    lineItem = GetAll(recipeID).LastOrDefault();
                }
            }

            return lineItem;
        }

        public LineItem() { }

        public LineItem(DataAccess.DataSet.LineItemsRow row)
        {
            ID = row.ID;
            RecipeID = row.RecipeID;
            IngredientID = row.IngredientID;
            Amount = row.Amount;
            Remarks = row.Remarks;
        }

        public long ID
        {
            get;
            set;
        }

        public long RecipeID
        {
            get;
            set;
        }

        public long IngredientID
        {
            get;
            set;
        }

        public string Amount
        {
            get;
            set;
        }

        public string Remarks
        {
            get;
            set;
        }
    }
}