﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Recipe
    {
        internal static DataAccess.DataSetTableAdapters.RecipesXTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.RecipesXTableAdapter();

        public static Recipe Get(long id)
        {
            Recipe recipe = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    recipe = new Recipe(data.FirstOrDefault());
                }
            }

            return recipe;
        }

        public static IEnumerable<Recipe> GetAll(long userID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByUserID(userID))
                {
                    yield return new Recipe(row);
                }
            }
        }

        public static IEnumerable<Recipe> GetSuggestions(long userID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetSuggestions(userID))
                {
                    yield return new Recipe(row);
                }
            }
        }

        public static Recipe Add(long userID, string name, long prepTime, long cookTime, long servings, string description, string imageUrl)
        {
            Recipe recipe = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(userID, name, prepTime, cookTime, servings, description, imageUrl) > 0)
                {
                    recipe = GetAll(userID).LastOrDefault();
                }
            }

            return recipe;
        }


        public Recipe() { }

        public Recipe(DataAccess.DataSet.RecipesXRow row)
        {
            ID = row.ID;
            UserID = row.UserID;
            Name = row.Name;
            PreparationTime = row.PreparationTime;
            CookingTime = row.CookingTime;
            Servings = row.Servings;
            Description = row.Description;
            ImageUrl = row.ImageUrl;
        }

        public long ID
        {
            get;
            set;
        }

        public long UserID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public long PreparationTime
        {
            get;
            set;
        }

        public long CookingTime
        {
            get;
            set;
        }

        public long Servings
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public string ImageUrl
        {
            get;
            set;
        }

        public IEnumerable<LineItem> LineItems
        {
            get
            {
                return LineItem.GetAll(ID);
            }
        }

        public IEnumerable<Direction> Directions
        {
            get
            {
                return Direction.GetAll(ID);
            }
        }
    }
}