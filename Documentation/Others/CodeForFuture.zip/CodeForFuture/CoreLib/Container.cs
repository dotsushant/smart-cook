﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.DataAccess;

namespace CodeTheFuture.CoreLib
{
    public class Container
    {
        internal static DataAccess.DataSetTableAdapters.ContainersTableAdapter m_sTA = new DataAccess.DataSetTableAdapters.ContainersTableAdapter();

        public static Container Get(long id)
        {
            Container Container = null;

            lock (m_sTA)
            {
                var data = m_sTA.GetByID(id);

                if (data.Count > 0)
                {
                    Container = new Container(data.FirstOrDefault());
                }
            }

            return Container;
        }

        public static IEnumerable<Container> GetAll(long userID)
        {
            lock (m_sTA)
            {
                foreach (var row in m_sTA.GetAllByUserID(userID))
                {
                    yield return new Container(row);
                }
            }
        }

        public static Container Add(long userID, long maxLevel, long ingredientID, long currentLevel)
        {
            Container container = null;

            lock (m_sTA)
            {
                if (m_sTA.Add(userID, maxLevel, ingredientID, currentLevel) > 0)
                {
                    container = Container.GetAll(userID).LastOrDefault();
                }
            }

            return container;
        }

        public static bool Update(long containerID, long currentLevel)
        {
            bool success = false;

            lock (m_sTA)
            {
                success = m_sTA.UpdateLevel(currentLevel, containerID) > 0;
            }

            return success;
        }

        public Container() { }

        public Container(DataAccess.DataSet.ContainersRow row)
        {
            ID = row.ID;
            UserID = row.UserID;
            MaxLevel = row.MaxLevel;
            IngredientID = row.IngredientID;
            CurrentLevel = row.CurrentLevel;
        }

        public long ID
        {
            get;
            set;
        }

        public long UserID
        {
            get;
            set;
        }

        public long MaxLevel
        {
            get;
            set;
        }

        public long IngredientID
        {
            get;
            set;
        }

        public long CurrentLevel
        {
            get;
            set;
        }
    }
}