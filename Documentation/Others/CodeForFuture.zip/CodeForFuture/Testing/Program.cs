﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using CodeTheFuture.CoreLib;

namespace Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            string email = "sk180579@gmail.com";
            var user = User.Get(email);

            // Add user
            if (user == null)
            {
                user = User.Add("Sushant", "Kumar", email);
            }

            // One time addition for now
            if (Ingredient.GetAll().Count() == 0)
            {
                // Add ingredients
                for (int ingredientID = 0; ingredientID < 10; ingredientID++)
                {
                    var ingredientName = string.Format("Ingredient {0}", ingredientID);
                    var ingredientDescription = string.Format("{0} {1}", "Test description for", ingredientName);
                    var ingredient = Ingredient.Add(ingredientName, ingredientDescription, "#", Guid.NewGuid().ToString());
                }
            }

            var random = new Random();

            if (Recipe.GetAll(user.ID).Count() == 0)
            {
                // Add recipes
                for (int recipeID = 0; recipeID < 10; recipeID++)
                {
                    var recipeName = string.Format("Recipe {0}", recipeID);
                    var recipeDescription = string.Format("{0} {1}", "Test description for", recipeName);
                    var recipe = Recipe.Add(user.ID, recipeName, random.Next(10, 20), random.Next(10, 40), random.Next(2, 6), recipeDescription, "image.html");

                    // Add directions
                    foreach (var directionID in Enumerable.Range(1, 10))
                    {
                        var recipeDirection = string.Format("Test direction {0} for {1}", directionID, recipeName);
                        Direction.Add(recipe.ID, recipeDirection);
                    }

                    // Add lineitems
                    foreach (var lineItemID in Enumerable.Range(1, 10))
                    {
                        var recipeLineItemRemark = string.Format("Test lineitem {0} remark for {1}", lineItemID, recipeName);
                        LineItem.Add(recipe.ID, random.Next(1, 9), string.Format("{0} units", random.Next(1, 20)), recipeLineItemRemark);
                    }
                }
            }

            if (Container.GetAll(user.ID).Count() == 0)
            {
                for (int ingredientID = 0; ingredientID < 10; ingredientID++)
                {
                    Container.Add(user.ID, 500, ingredientID, 100);
                }
            }
        }
    }
}